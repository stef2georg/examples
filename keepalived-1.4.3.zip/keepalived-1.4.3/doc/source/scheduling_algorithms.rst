##########################
IPVS Scheduling Algorithms
##########################

The following scheduling algorithms are supported by the IPVS kernel code.

Round Robin
***********

Weighted Round Robin
********************

Least Connection
****************

Weighted Least Connection
*************************

Locality-Based Least Connection
*******************************

Locality-Based Least Connection with Replication
************************************************

Destination Hashing
*******************

Source Hashing
**************

Shortest Expected Delay
***********************

Never Queue
***********

